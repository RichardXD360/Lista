﻿using System.IO;
class Escrever
{
    public void Escreva()
    {
        try
        {
            StreamWriter esc = new StreamWriter("C:\\Users\\richard.reis\\Desktop\\Titulo_do_texto.txt"); //  "C:\\Teste.txt"
            Console.WriteLine("Escreva o texto desejado");
            string txt = Console.ReadLine();
            esc.WriteLine(txt);
            esc.Close();
        }
        catch(Exception ex) 
        {
            Console.WriteLine("Exception: "+ ex.Message);
        }
        finally
        {
            Console.WriteLine("Sucesso");
        }
    }
}