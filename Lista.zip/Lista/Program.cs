﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;

using System;
using System.Collections.Generic;
class Program
{
    static void Main(string[] args)
    {
        List<string> ListaToDo = new List<string>(); // Adição da lista
        string comando = "";

        while (comando != "SAIR")
        {
            Console.WriteLine("O que deseja realizar?");
            Console.WriteLine("Add, Ver, Remover, Leitor, Sair");
            comando = Console.ReadLine().ToUpper();

            switch (comando)
            {
                case "ADD":
                    AddItem(ListaToDo);
                    break;

                case "VER":
                    VerItem(ListaToDo);
                    break;

                case "REMOVER":
                    RemoverItem(ListaToDo);
                    break;

                case "LEITOR":
                    Leitor leitor_txt = new Leitor();
                    leitor_txt.Ler();
                    break;

                case "ESCRITOR":
                    Escrever escrever = new Escrever();
                    escrever.Escreva("Titulo_do_texto.txt");
                    break;
                case "SAIR":
                    Console.WriteLine("Saindo...");
                    break;
            }
        }
    }

    static void AddItem(List<string> ListaToDo)
    {
        Console.Clear();
        Console.WriteLine("Adicione itens aqui:");
        string item = Console.ReadLine();
        ListaToDo.Add(item);
        Console.WriteLine("Item adicionado.");
        Thread.Sleep(2000);
        Console.Clear();
    }

    static void VerItem(List<string> ListaToDo)
    {
        if (ListaToDo.Count > 0)
        {
            Console.WriteLine("Segue itens da sua lista:");
            for (int i = 0; i < ListaToDo.Count; i++)
            {
                Console.WriteLine($"{i + 1} - {ListaToDo[i]}");
            }
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Não há itens na lista, adicione-os primeiro");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }

    static void RemoverItem(List<string> ListaToDo)
    {
        Console.WriteLine("Segue itens da Lista:");
        for (int i = 0; i < ListaToDo.Count; i++)
        {
            Console.WriteLine($"{i + 1} - {ListaToDo[i]}");
        }
        Console.WriteLine("Cite o número do item que deseja remover:");
        string item_remove = Console.ReadLine();
        bool correto = int.TryParse(item_remove, out int item_removido);
        if (correto && item_removido > 0 && item_removido <= ListaToDo.Count)
        {
            ListaToDo.RemoveAt(item_removido - 1);
            Console.WriteLine("Item removido.");
            Thread.Sleep(2000);
            Console.Clear();
        }
        else
        {
            Console.WriteLine("Item inválido.");
            Thread.Sleep(2000);
            Console.Clear();
        }
    }
}
